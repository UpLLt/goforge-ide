#!/usr/bin/env python3
"""Windows-native package checks. Runs only generated fixtures, never user projects.

This verifies the native launcher and actual bundled Go/gopls/Delve engines. It
does not turn headless startup or debugger protocol checks into IDE UI acceptance.
"""
from __future__ import annotations
import argparse
import ctypes
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import sys
import threading
import tempfile
import time
from urllib.parse import unquote

ROOT=Path(__file__).resolve().parents[1]


def native_environment(app, temporary, inherited):
    """Keep generated native fixtures independent of the invoking user's Go setup."""
    blocked={'GOROOT','GOPATH','GOBIN','GOFLAGS','GOWORK','GOOS','GOARCH','GOAMD64',
             'GOEXPERIMENT','GOPACKAGESDRIVER','GOMODCACHE','GOPROXY','GOSUMDB',
             'GOPRIVATE','GONOPROXY','GONOSUMDB','GOVCS','GOFORGE_JDK',
             'GOFORGE_VM_OPTIONS','GOFORGE_PROPERTIES','JAVA_TOOL_OPTIONS','JDK_JAVA_OPTIONS',
             '_JAVA_OPTIONS','JAVA_HOME','JDK_HOME','IDEA_JDK','IDEA_VM_OPTIONS','IDEA_PROPERTIES',
             'PSMODULEPATH'}
    env={k.upper():v for k,v in inherited.items() if k.upper() not in blocked}
    if not env.get('SYSTEMROOT'):
        raise RuntimeError('Windows verification requires SystemRoot')
    env.update(APPDATA=str(temporary/'Roaming'),LOCALAPPDATA=str(temporary/'Local'),
               GOENV='off',GOTOOLCHAIN='local',CGO_ENABLED='0',GOWORK='off',
               GOOS='windows',GOARCH='amd64',GOAMD64='v1',GOPACKAGESDRIVER='off',
               GOPATH=str(temporary/'gopath'),GOMODCACHE=str(temporary/'gopath/pkg/mod'),
               GOCACHE=str(temporary/'gocache'),GOTELEMETRY='off',GOPROXY='off',
               GOSUMDB='off',GOPRIVATE='',GONOPROXY='',GONOSUMDB='',GOVCS='*:off',
               PATH=os.pathsep.join([str(app/'goforge-tools/go/bin'),str(app/'goforge-tools/bin'),
                                     str(Path(env['SYSTEMROOT'])/'System32')]))
    return env


def fixture_hashes(project):
    """Snapshot all Go inputs, including a newly added source or module file."""
    return {path.relative_to(project).as_posix():hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(project.rglob('*')) if path.is_file()
            and (path.suffix=='.go' or path.name in ('go.mod','go.sum','go.work','go.work.sum'))}


def require_fixture_unchanged(project, baseline):
    actual=fixture_hashes(project)
    if actual!=baseline:
        raise RuntimeError('Generated fixture Go inputs changed during read-only verification')
    return {'passed':True,'sha256':actual}


def require_adapter_success(process):
    code=process.wait(timeout=15)
    if code!=0:
        raise RuntimeError('Delve adapter returned '+str(code)+' after disconnect')


def require_windows_host():
    if os.name!='nt':
        raise RuntimeError('Windows native validation requires Windows; cross-platform runs are rejected')


def rename_file_counts(edit, expected, replacement):
    if not isinstance(edit,dict):raise RuntimeError('Missing workspace rename edit')
    changes=edit.get('changes')
    if changes is None:
        changes={}
        for item in edit.get('documentChanges',[]):
            if 'textDocument' not in item or 'edits' not in item:
                raise RuntimeError('Unexpected resource operation in symbol rename')
            uri=item['textDocument']['uri']
            if uri in changes:raise RuntimeError('Duplicate rename document')
            changes[uri]=item['edits']
    actual={unquote(uri).casefold():values for uri,values in changes.items()}
    if set(actual)!={unquote(uri).casefold() for uri in expected}:
        raise RuntimeError('Symbol rename did not cover exactly the generated caller and declaration files')
    if any(not values or any(v.get('newText')!=replacement for v in values) for values in actual.values()):
        raise RuntimeError('Unexpected rename edit text')
    return {uri:len(values) for uri,values in changes.items()}


def load_protocol():
    spec=importlib.util.spec_from_file_location('goforge_windows_wire',ROOT/'scripts/verify-protocols.py')
    p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
    # Cold Windows Go builds can exceed the small development-probe timeout.
    base=p.FramedJson
    class WindowsFramedJson(base):
        def receive_until(self,predicate,timeout=120):
            return super().receive_until(predicate,timeout)
    p.FramedJson=WindowsFramedJson
    return p


def command(args, **kwargs):
    p=subprocess.run([str(x) for x in args],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                     text=True,encoding='utf-8',errors='replace',timeout=kwargs.pop('timeout',120),**kwargs)
    if p.returncode: raise RuntimeError(f'{Path(args[0]).name} returned {p.returncode}: {p.stdout[-5000:]}')
    return p.stdout


def windows_file_metadata(executable, inherited):
    """Read PE metadata with the Windows PowerShell built-in modules, not inherited PS7 modules."""
    env={key.upper():value for key,value in inherited.items() if key.upper()!='PSMODULEPATH'}
    if not env.get('SYSTEMROOT'):
        raise RuntimeError('Windows metadata verification requires SystemRoot')
    home=Path(env['SYSTEMROOT'])/'System32/WindowsPowerShell/v1.0'
    env['GOFORGE_VERIFY_EXE']=str(executable)
    script=(
        "$ErrorActionPreference='Stop'; "
        "$env:PSModulePath=[System.IO.Path]::Combine($PSHOME,'Modules'); "
        "$PSModuleAutoLoadingPreference='None'; "
        "$security=Import-Module -Name ([System.IO.Path]::Combine($PSHOME,'Modules','Microsoft.PowerShell.Security','Microsoft.PowerShell.Security.psd1')) -PassThru -ErrorAction Stop; "
        "$utility=Import-Module -Name ([System.IO.Path]::Combine($PSHOME,'Modules','Microsoft.PowerShell.Utility','Microsoft.PowerShell.Utility.psd1')) -PassThru -ErrorAction Stop; "
        "$v=[System.Diagnostics.FileVersionInfo]::GetVersionInfo($env:GOFORGE_VERIFY_EXE); "
        "$s=Microsoft.PowerShell.Security\\Get-AuthenticodeSignature -LiteralPath $env:GOFORGE_VERIFY_EXE -ErrorAction Stop; "
        "@{properties=@{product=$v.ProductName; description=$v.FileDescription; original=$v.OriginalFilename; signature=$s.Status.ToString()}; "
        "powershell=@{home=$PSHOME; edition=$PSVersionTable.PSEdition; version=$PSVersionTable.PSVersion.ToString(); securityModule=$security.ModuleBase; utilityModule=$utility.ModuleBase}} "
        "| Microsoft.PowerShell.Utility\\ConvertTo-Json -Compress -Depth 3")
    metadata=json.loads(command([home/'powershell.exe','-NoProfile','-NonInteractive','-Command',script],env=env))
    properties=metadata.get('properties') if isinstance(metadata,dict) else None
    runtime=metadata.get('powershell') if isinstance(metadata,dict) else None
    if not isinstance(properties,dict) or not all(isinstance(properties.get(key),str) for key in
            ('product','description','original','signature')) or not properties['signature']:
        raise RuntimeError('Windows metadata query did not return version and signature properties')
    if not isinstance(runtime,dict) or runtime.get('edition')!='Desktop' or not str(runtime.get('version','')).startswith('5.1.'):
        raise RuntimeError('Windows metadata query did not use Windows PowerShell 5.1 Desktop')
    for key,expected in [('home',home),('securityModule',home/'Modules/Microsoft.PowerShell.Security'),
                         ('utilityModule',home/'Modules/Microsoft.PowerShell.Utility')]:
        actual=runtime.get(key)
        if not isinstance(actual,str) or Path(actual).resolve()!=expected.resolve():
            raise RuntimeError('Windows metadata query used an unexpected PowerShell module path: '+key)
    return metadata


def terminate_owned(p):
    if p and p.poll() is None:
        subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],capture_output=True,timeout=15)
        p.wait(timeout=15)


def pid_handle(pid):
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.OpenProcess.restype=ctypes.c_void_p
    handle=kernel.OpenProcess(0x00100000|0x1000,False,pid)
    if not handle: raise RuntimeError('Cannot observe generated debuggee process '+str(pid))
    return handle


def require_exited(handle):
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_uint32]
    kernel.CloseHandle.argtypes=[ctypes.c_void_p]
    try:
        if kernel.WaitForSingleObject(handle,10000)!=0: raise RuntimeError('Generated debuggee did not exit')
    finally:kernel.CloseHandle(handle)



def cleanup_debug_session(process, conn, reader, writer, target, original_error):
    """Unblock protocol reads before closing buffered streams; preserve the primary failure."""
    failures=[]
    def attempt(operation, action):
        try:action()
        except Exception as error:failures.append((operation,error))
    if conn:
        try:conn.shutdown(socket.SHUT_RDWR)
        except OSError:pass  # The peer may have completed its normal disconnect already.
    attempt('terminate owned adapter',lambda:terminate_owned(process))
    if target:attempt('wait for generated debuggee',lambda:require_exited(target))
    def close_streams():
        for name,stream in (('writer',writer),('reader',reader),('socket',conn)):
            if stream:attempt('close '+name,stream.close)
    closer=threading.Thread(target=close_streams,name='GoForge debugger stream cleanup',daemon=True)
    closer.start();closer.join(timeout=2)
    if closer.is_alive():failures.append(('close protocol streams',TimeoutError('Protocol stream cleanup exceeded 2 seconds')))
    if failures:
        details=[operation+': '+type(error).__name__+': '+str(error) for operation,error in failures]
        if original_error is not None:
            # BaseException.add_note is only available in Python 3.11+.
            original_error.__notes__=list(getattr(original_error,'__notes__',[]))+['Native debugger cleanup: '+detail for detail in details]
        else:raise RuntimeError('Native debugger cleanup failed: '+'; '.join(details)) from failures[0][1]


def debug(wire, app, project, env, out, cancel=False):
    log=out/('delve-cancel.log' if cancel else 'delve-full.log')
    process=conn=None; target=None; reader=writer=None
    with log.open('w',encoding='utf-8') as stream:
        try:
            process=subprocess.Popen([str(app/'goforge-tools/bin/dlv.exe'),'dap','--listen=127.0.0.1:0'],
                                     cwd=project,env=env,stdout=stream,stderr=stream)
            deadline=time.monotonic()+20; match=None
            while time.monotonic()<deadline:
                match=re.search(r'DAP server listening at: (127\.0\.0\.1):(\d+)',log.read_text(encoding='utf-8'))
                if match:break
                if process.poll() is not None:raise RuntimeError('Delve exited before ready: '+log.read_text(encoding='utf-8'))
                time.sleep(.05)
            if not match:raise TimeoutError('Delve listener')
            conn=socket.create_connection((match[1],int(match[2])),timeout=10);conn.settimeout(None)
            reader,writer=conn.makefile('rb'),conn.makefile('wb');rpc=wire.FramedJson(reader,writer)
            rpc.dap('initialize',{'clientID':'goforge-windows-native','adapterID':'go','pathFormat':'path',
                                 'linesStartAt1':True,'columnsStartAt1':True})
            rpc.dap('launch',{'request':'launch','mode':'debug','program':str(project),'cwd':str(project)})
            rpc.receive_until(lambda m:m.get('event')=='initialized')
            bp=rpc.dap('setBreakpoints',{'source':{'path':str(project/'main.go')},'breakpoints':[{'line':5}]})
            assert bp['breakpoints'][0]['verified'],bp
            rpc.dap('configurationDone')
            stopped=rpc.receive_until(lambda m:m.get('event')=='stopped')
            assert stopped['body']['reason']=='breakpoint',stopped
            event=rpc.receive_until(lambda m:m.get('event')=='process')
            target=pid_handle(event['body']['systemProcessId'])
            thread=stopped['body']['threadId']
            frames=rpc.dap('stackTrace',{'threadId':thread})['stackFrames'];frame=frames[0]
            assert frame['line']==5,frame
            scopes=rpc.dap('scopes',{'frameId':frame['id']})['scopes'];variables=[]
            for scope in scopes:
                if not scope.get('expensive'):
                    variables+=rpc.dap('variables',{'variablesReference':scope['variablesReference']})['variables']
            assert any(v['name']=='message' and 'Windows native' in v['value'] for v in variables),variables
            watch=rpc.dap('evaluate',{'expression':'message','frameId':frame['id'],'context':'watch'})
            assert 'Windows native' in watch['result'],watch
            if cancel:
                rpc.dap('disconnect',{'terminateDebuggee':True})
            else:
                rpc.dap('next',{'threadId':thread})
                rpc.receive_until(lambda m:m.get('event')=='stopped' and m.get('body',{}).get('reason')=='step')
                rpc.dap('continue',{'threadId':thread})
                exited=rpc.receive_until(lambda m:m.get('event')=='exited')
                assert exited['body']['exitCode']==0,exited
                rpc.receive_until(lambda m:m.get('event')=='terminated')
                rpc.dap('disconnect',{'terminateDebuggee':False})
            require_adapter_success(process);observed=target;target=None;require_exited(observed)
            return {'passed':True,'adapterExitCode':process.returncode,'targetExited':True,
                    'scope':'launch/breakpoint/locals/evaluate/'+('cancel cleanup' if cancel else 'step/continue/exit cleanup'),
                    'protocol':rpc.dap_diagnostics()}
        finally:
            cleanup_debug_session(process,conn,reader,writer,target,sys.exc_info()[1])


def lsp(wire,app,project,env,out):
    with (out/'gopls.log').open('w',encoding='utf-8') as log:
        p=subprocess.Popen([str(app/'goforge-tools/bin/gopls.exe'),'serve'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,
                           stderr=log,cwd=project,env=env)
        try:
            rpc=wire.FramedJson(p.stdout,p.stdin)
            capabilities=rpc.lsp('initialize',{'processId':os.getpid(),'rootUri':project.as_uri(),
                                 'capabilities':{'textDocument':{'completion':{'completionItem':{'snippetSupport':True}}}},
                                 'workspaceFolders':[{'uri':project.as_uri(),'name':'Windows native'}]})['capabilities']
            assert capabilities.get('definitionProvider') and capabilities.get('renameProvider'),capabilities
            rpc.notify('initialized',{})
            source=project/'main.go';text=source.read_text(encoding='utf-8')
            rpc.notify('textDocument/didOpen',{'textDocument':{'uri':source.as_uri(),'languageId':'go','version':1,'text':text}})
            result=rpc.lsp('textDocument/definition',{'textDocument':{'uri':source.as_uri()},'position':{'line':3,'character':14}})
            assert isinstance(result,list) and result,result
            location=result[0]
            assert unquote(location['uri']).casefold()==unquote((project/'hello.go').as_uri()).casefold(),result
            assert location['range']['start']=={'line':1,'character':5},result
            at={'textDocument':{'uri':source.as_uri()},'position':{'line':3,'character':14}}
            rename=rpc.lsp('textDocument/rename',{**at,'newName':'Welcome'})
            counts=rename_file_counts(rename,[(project/name).as_uri()
                for name in ('main.go','hello.go','hello_test.go')],'Welcome')
            completion=rpc.lsp('textDocument/completion',{**at,'context':{'triggerKind':1}})
            items=completion if isinstance(completion,list) else completion.get('items',[])
            assert any(item.get('label')=='Hello' for item in items),completion
            changed=text.replace('Hello()','MissingSymbol()')
            rpc.notify('textDocument/didChange',{'textDocument':{'uri':source.as_uri(),'version':2},
                       'contentChanges':[{'text':changed}]})
            diagnostics=rpc.receive_until(lambda m:m.get('method')=='textDocument/publishDiagnostics'
                and m.get('params',{}).get('uri')==source.as_uri()
                and any('MissingSymbol' in d.get('message','') for d in m['params'].get('diagnostics',[])))
            rpc.notify('textDocument/didChange',{'textDocument':{'uri':source.as_uri(),'version':3},
                       'contentChanges':[{'text':text}]})
            rpc.receive_until(lambda m:m.get('method')=='textDocument/publishDiagnostics'
                and m.get('params',{}).get('uri')==source.as_uri() and m['params'].get('version')==3
                and not any(d.get('severity')==1 for d in m['params'].get('diagnostics',[])))
            rpc.lsp('shutdown');rpc.notify('exit');p.wait(timeout=15)
            assert p.returncode==0,p.returncode
            return {'passed':True,'definitionResponse':result,'renameEditCounts':counts,
                    'completionLabel':'Hello','unsavedDiagnosticCount':len(diagnostics['params']['diagnostics']),
                    'restoredOverlayErrors':0,'renameApplied':False,'exitCode':p.returncode}
        finally:terminate_owned(p)


def main(app,report):
    app=app.resolve();report.mkdir(parents=True,exist_ok=True)
    result={'passed':False,'scope':'Native launcher and bundled engines; IDE GUI feature validation remains separate',
            'app':str(app),'hostOS':os.name,'checks':{}}
    try:
        require_windows_host()
        build_inputs=app/'goforge-build-inputs.json'
        identity=json.loads(build_inputs.read_text(encoding='utf-8'))
        result.update(pluginZipSha256=identity['pluginZipSha256'],
                      buildInputsSha256=hashlib.sha256(build_inputs.read_bytes()).hexdigest(),
                      launcherSha256=hashlib.sha256((app/'bin/goforge64.exe').read_bytes()).hexdigest())
        wire=load_protocol()
        with tempfile.TemporaryDirectory(prefix='GoForge relocation 中文 ') as temporary:
            temp=Path(temporary);relocated=temp/'GoForge relocated';shutil.copytree(app,relocated)
            env=native_environment(relocated,temp,os.environ)
            for name in ('APPDATA','LOCALAPPDATA'):Path(env[name]).mkdir()
            metadata=windows_file_metadata(relocated/'bin/goforge64.exe',env)
            resources=metadata['properties']
            assert resources=={'product':'GoForge','description':'GoForge','original':'goforge64.exe','signature':'NotSigned'},resources
            result['checks']['windowsVersionAndSignature']={'passed':True,**metadata}
            probe=command([relocated/'bin/goforge64.exe','goforge-package-info'],env=env,timeout=120)
            assert 'product=GoForge' in probe and str(relocated).lower() in probe.lower(),probe
            runtime=next(x.removeprefix('runtime=') for x in probe.splitlines() if x.startswith('runtime='))
            assert Path(runtime).resolve()==(relocated/'jbr').resolve(),runtime
            for key in ('config','system','plugins','log'):
                line=next(x for x in probe.splitlines() if x.startswith(key+'='));assert str(temp).lower() in line.lower(),line
            result['checks']['nativeLauncherRelocation']={'passed':True,'output':probe}
            go=relocated/'goforge-tools/go/bin/go.exe'
            assert Path(command([go,'env','GOROOT'],env=env).strip()).resolve()==(relocated/'goforge-tools/go').resolve()
            versions={name:command([relocated/path,*args],env=env) for name,path,args in [
                ('go','goforge-tools/go/bin/go.exe',['version']),('gopls','goforge-tools/bin/gopls.exe',['version']),
                ('dlv','goforge-tools/bin/dlv.exe',['version']),('node','goforge-tools/bin/node.exe',['--version']),
                ('devcontainers','goforge-tools/bin/node.exe',[str(relocated/'goforge-tools/devcontainer-cli/dist/spec-node/devContainersSpecCLI.js'),'--version'])]}
            for name,needle in {'go':'go1.26.4','gopls':'v0.23.0','dlv':'1.27.2','node':'v24.22.1','devcontainers':'0.89.0'}.items():assert needle in versions[name],versions
            result['checks']['versions']={'passed':True,'outputs':versions}
            project=temp/'fixture space 中文';project.mkdir()
            (project/'go.mod').write_text('module example.com/windows-native\n\ngo 1.26\n',encoding='utf-8')
            (project/'main.go').write_text('package main\nimport "fmt"\nfunc main() {\n message := Hello()\n fmt.Println(message)\n fmt.Println("done")\n}\n',encoding='utf-8')
            (project/'hello.go').write_text('package main\nfunc Hello() string { return "Windows native" }\n',encoding='utf-8')
            (project/'hello_test.go').write_text('package main\nimport "testing"\nfunc TestHello(t *testing.T) { if Hello() != "Windows native" { t.Fatal(Hello()) } }\n',encoding='utf-8')
            baseline=fixture_hashes(project)
            result['checks']['test']={'passed':True,'output':command([go,'test','-count=1','./...'],cwd=project,env=env)}
            output=command([go,'run','.'],cwd=project,env=env);assert 'Windows native' in output
            result['checks']['run']={'passed':True,'output':output}
            result['checks']['gopls']=lsp(wire,relocated,project,env,report)
            result['checks']['debug']=debug(wire,relocated,project,env,report)
            result['checks']['debugCancel']=debug(wire,relocated,project,env,report,cancel=True)
            result['checks']['fixtureUnchanged']=require_fixture_unchanged(project,baseline)
            result['passed']=True
    except BaseException as error:
        result['passed']=False
        result['error']=type(error).__name__+': '+str(error)
        if getattr(error,'__notes__',None):result['cleanupNotes']=list(error.__notes__)
        raise
    finally:
        (report/'native-verification.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
        print(json.dumps(result,indent=2,ensure_ascii=True))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--app',type=Path,default=ROOT/'build/windows/GoForge')
    parser.add_argument('--report-dir',type=Path,default=ROOT/'.artifacts/windows-native')
    args=parser.parse_args();main(args.app,args.report_dir)
